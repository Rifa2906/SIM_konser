<script src="<?= base_url('assets/ruang-admin'); ?>/vendor/jquery/jquery.min.js"></script>
<script src="<?= base_url('assets/ruang-admin'); ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url('assets/ruang-admin'); ?>/vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="<?= base_url('assets/ruang-admin'); ?>/js/ruang-admin.min.js"></script>
</body>

</html>